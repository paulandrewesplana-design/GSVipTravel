# GS VIP Travel Website

## Publish with GitHub Pages
1. Create a public GitHub repository named `gsviptravel`.
2. Upload `index.html`, `README.md`, and the entire `images` folder to the repository root.
3. Open **Settings → Pages**.
4. Set Source to **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then Save.
6. Your site will be published at `https://YOUR-USERNAME.github.io/gsviptravel/`.

Do not upload only `index.html`; the `images` folder must remain beside it.
